# iUmrah Telegram link integration

This patch adds one trusted Web API route:

`POST /api/telegram/link`

Client request:

```http
POST /api/telegram/link
x-booking-token: <the existing booking access token>
Content-Type: application/json

{ "bookingId": "IUM-2026-XXXXXXX", "language": "ru" }
```

Response:

```json
{
  "ok": true,
  "linkUrl": "https://t.me/<bot>?start=link_<one-time-token>",
  "expiresAt": "..."
}
```

The route never exposes the Telegram bridge secret to browsers or mobile clients. It forwards the already-existing booking token server-to-server to the bot Worker. The bot verifies booking ownership against the same iUmrah operational trip API, encrypts the booking access token at rest, and creates a one-time token valid for 10 minutes.

Cloudflare / runtime variables required by iumrah-web:

- `IUMRAH_TELEGRAM_BOT_WORKER_URL=https://<your-bot-worker-domain>`
- `IUMRAH_TELEGRAM_BRIDGE_SECRET=<same value configured in the bot Worker>`
