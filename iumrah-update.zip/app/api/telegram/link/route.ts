import { getCloudflareContext } from "@opennextjs/cloudflare";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type TelegramBridgeEnv = {
  IUMRAH_TELEGRAM_BOT_WORKER_URL?: string;
  IUMRAH_TELEGRAM_BRIDGE_SECRET?: string;
};

function clean(value: unknown, max = 512) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function config() {
  let cloudflare: TelegramBridgeEnv = {};
  try {
    cloudflare = getCloudflareContext().env as unknown as TelegramBridgeEnv;
  } catch {
    // Local Next.js development can rely on process.env.
  }
  const workerURL = clean(process.env.IUMRAH_TELEGRAM_BOT_WORKER_URL ?? cloudflare.IUMRAH_TELEGRAM_BOT_WORKER_URL).replace(/\/+$/, "");
  const secret = clean(process.env.IUMRAH_TELEGRAM_BRIDGE_SECRET ?? cloudflare.IUMRAH_TELEGRAM_BRIDGE_SECRET, 1024);
  return { workerURL, secret };
}

export async function POST(request: Request) {
  const bookingToken = clean(request.headers.get("x-booking-token"), 256);
  if (bookingToken.length < 24) {
    return NextResponse.json({ error: "BOOKING_NOT_FOUND" }, { status: 404, headers: { "Cache-Control": "no-store" } });
  }

  let body: Record<string, unknown>;
  try {
    body = await request.json() as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "INVALID_REQUEST" }, { status: 400, headers: { "Cache-Control": "no-store" } });
  }

  const bookingId = clean(body.bookingId ?? body.bookingID, 64);
  const language = clean(body.language, 16) || "ru";
  if (!/^IUM-\d{4}-[A-Z2-9]{7}$/.test(bookingId)) {
    return NextResponse.json({ error: "INVALID_BOOKING" }, { status: 400, headers: { "Cache-Control": "no-store" } });
  }

  const { workerURL, secret } = config();
  if (!workerURL || !secret) {
    return NextResponse.json({ error: "TELEGRAM_BRIDGE_NOT_CONFIGURED" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }

  try {
    const upstream = await fetch(`${workerURL}/internal/link-token`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "authorization": `Bearer ${secret}`,
      },
      body: JSON.stringify({ bookingId, bookingToken, language }),
      cache: "no-store",
    });
    const payload = await upstream.json().catch(() => ({ error: "INVALID_TELEGRAM_BRIDGE_RESPONSE" }));
    return NextResponse.json(payload, { status: upstream.status, headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("telegram-link-create-failed", error);
    return NextResponse.json({ error: "TELEGRAM_BRIDGE_UNAVAILABLE" }, { status: 502, headers: { "Cache-Control": "no-store" } });
  }
}
