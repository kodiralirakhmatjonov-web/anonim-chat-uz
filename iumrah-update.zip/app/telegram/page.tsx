import type { Metadata } from "next";
import { TelegramProductPage } from "@/components/telegram/TelegramProductPage";

export const metadata: Metadata = {
  title: "iUmrah Booking Status — Telegram",
  description: "Connect your iUmrah booking to Telegram for live booking status, countdowns and important trip notifications.",
};

export default function TelegramPage() {
  return <TelegramProductPage />;
}
