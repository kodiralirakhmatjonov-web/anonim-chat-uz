"use client";

import Image from "next/image";
import Link from "next/link";
import { useSiteLocale } from "@/components/site/SiteLocaleProvider";
import type { SiteLocale } from "@/lib/site-i18n";
import styles from "./HomePage.module.css";

const APP_STORE_URL = "https://apps.apple.com/uz/app/iumrah-%D0%BF%D1%80%D0%B8%D0%B2%D0%B0%D1%82%D0%BD%D0%B0%D1%8F-%D1%83%D0%BC%D1%80%D0%B0/id6759577859?l=ru";

type FooterCopy = {
  description: string;
  download: string;
  appStore: string;
  legal: string;
  platform: string;
  services: string;
  company: string;
  home: string;
  flights: string;
  hotels: string;
  configurator: string;
  id: string;
  bookings: string;
  journey: string;
  care: string;
  advisor: string;
  bookingStatusBot: string;
  about: string;
  support: string;
  privacy: string;
  refund: string;
};

const COPY: Record<SiteLocale, FooterCopy> = {
  ru: {
    description: "Персональная Umrah — перелёт, отели, трансфер и поддержка в одной платформе.",
    download: "Загрузить в", appStore: "App Store", legal: "iumrah · Born in Makkah · Since 2026",
    platform: "Платформа", services: "Сервисы", company: "Информация",
    home: "Главная", flights: "Авиабилеты", hotels: "Отели", configurator: "Собрать Умру", id: "Iumrah ID", bookings: "Бронирования", journey: "Моя поездка",
    care: "Iumrah Care", advisor: "Advisor", bookingStatusBot: "iUmrah Booking Status · Telegram-бот", about: "О проекте", support: "Поддержка",
    privacy: "Конфиденциальность", refund: "Возвраты",
  },
  en: {
    description: "Private Umrah — flights, hotels, transfer and care in one platform.",
    download: "Download on the", appStore: "App Store", legal: "iumrah · Born in Makkah · Since 2026",
    platform: "Platform", services: "Services", company: "Company",
    home: "Home", flights: "Flights", hotels: "Hotels", configurator: "Build Umrah", id: "Iumrah ID", bookings: "Bookings", journey: "My trip",
    care: "Iumrah Care", advisor: "Advisor", bookingStatusBot: "iUmrah Booking Status · Telegram bot", about: "About", support: "Support",
    privacy: "Privacy", refund: "Refunds",
  },
  uz: {
    description: "Shaxsiy Umra — parvoz, mehmonxona, transfer va yordam bitta platformada.",
    download: "Yuklab oling", appStore: "App Store", legal: "iumrah · Born in Makkah · Since 2026",
    platform: "Platforma", services: "Xizmatlar", company: "Ma’lumot",
    home: "Bosh sahifa", flights: "Aviabiletlar", hotels: "Mehmonxonalar", configurator: "Umra yaratish", id: "Iumrah ID", bookings: "Bronlar", journey: "Safarim",
    care: "Iumrah Care", advisor: "Advisor", bookingStatusBot: "iUmrah Booking Status · Telegram bot", about: "Loyiha haqida", support: "Yordam",
    privacy: "Maxfiylik", refund: "Qaytarish",
  },
  "uz-Cyrl": {
    description: "Шахсий Умра — парвоз, меҳмонхона, трансфер ва ёрдам битта платформада.",
    download: "Юклаб олинг", appStore: "App Store", legal: "iumrah · Born in Makkah · Since 2026",
    platform: "Платформа", services: "Хизматлар", company: "Маълумот",
    home: "Бош саҳифа", flights: "Авиабилетлар", hotels: "Меҳмонхоналар", configurator: "Умра яратиш", id: "Iumrah ID", bookings: "Бронлар", journey: "Сафарим",
    care: "Iumrah Care", advisor: "Advisor", bookingStatusBot: "iUmrah Booking Status · Telegram бот", about: "Лойиҳа ҳақида", support: "Ёрдам",
    privacy: "Махфийлик", refund: "Қайтариш",
  },
};

function AppleLogo() {
  return (
    <svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true" focusable="false">
      <path fill="currentColor" d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.32.03-1.75-.79-3.27-.79-1.51 0-1.99.76-3.24.82-1.3.05-2.29-1.31-3.12-2.54-1.7-2.47-3-6.95-1.25-10.04.85-1.22 2.38-2 4-2.03 1.26-.02 2.45.85 3.27.85.79 0 2.27-1.05 3.82-.9.65.03 2.47.26 3.64 1.98-3.14 1.88-2.64 6.93.49 8.18-.57 1.5-1.31 2.99-2.13 4.06zM13.5 3.9c.7-.8 1.82-1.4 2.87-1.44.13 1.16-.34 2.35-1 3.19-.66.85-1.75 1.51-2.83 1.43-.15-1.14.39-2.36.96-3.18z" />
    </svg>
  );
}

export function MarketingFooter() {
  const { locale } = useSiteLocale();
  const copy = COPY[locale];

  return (
    <footer className={styles.marketingFooter}>
      <div className={styles.footerTopGrid}>
        <div className={styles.footerBrandColumn}>
          <Image src="/iumrah-logo-clean.png" alt="iumrah" width={1792} height={704} className={styles.footerBrand} />
          <p>{copy.description}</p>
          <a className={styles.appStoreButton} href={APP_STORE_URL} target="_blank" rel="noreferrer" aria-label={`${copy.download} ${copy.appStore}`}>
            <span className={styles.appleMark}><AppleLogo /></span>
            <span><small>{copy.download}</small><strong>{copy.appStore}</strong></span>
          </a>
        </div>

        <nav className={styles.footerNav} aria-label="Sitemap">
          <div>
            <strong>{copy.platform}</strong>
            <Link href="/">{copy.home}</Link>
            <Link href="/flights">{copy.flights}</Link>
            <Link href="/hotels">{copy.hotels}</Link>
            <Link href="/generator">{copy.configurator}</Link>
            <Link href="/booking">{copy.bookings}</Link>
            <Link href="/account">{copy.id}</Link>
          </div>
          <div>
            <strong>{copy.services}</strong>
            <Link href="/care">{copy.care}</Link>
            <Link href="/products/advisor">{copy.advisor}</Link>
            <Link href="/telegram">{copy.bookingStatusBot}</Link>
            <Link href="/journey">{copy.journey}</Link>
            <Link href="/support">{copy.support}</Link>
          </div>
          <div>
            <strong>{copy.company}</strong>
            <Link href="/about">{copy.about}</Link>
            <Link href="/privacy">{copy.privacy}</Link>
            <Link href="/refund">{copy.refund}</Link>
          </div>
        </nav>
      </div>

      <div className={styles.footerContact}>
        <a href="tel:+998508898845">+998 50 889 88 45</a>
        <a href="tg://resolve?phone=998508898845">Telegram · +998 50 889 88 45</a>
        <Link href="/telegram">{copy.bookingStatusBot}</Link>
      </div>

      <div className={styles.footerBottom}>
        <span>© 2026 iumrah. Все права защищены.</span>
        <span className={styles.footerDomains}>
          <a href="https://iumrah.uz">iumrah.uz</a>
          <a href="https://iumrahproject.com">iumrahproject.com</a>
          <a href="https://iumrah.app">iumrah.app</a>
        </span>
      </div>
    </footer>
  );
}
