"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Symbol } from "@/components/design/Symbol";
import { useSiteLocale } from "@/components/site/SiteLocaleProvider";
import type { SiteLocale } from "@/lib/site-i18n";
import { loadBooking, type StoredWebBooking } from "@/lib/web-package";
import { TelegramConnectCard } from "./TelegramConnectCard";
import styles from "./TelegramProductPage.module.css";

type Copy = {
  eyebrow: string; titleA: string; titleB: string; lead: string; primary: string; noBooking: string;
  demoKicker: string; demoTitle: string; demoBody: string; demoTimer: string; demoRef: string; demoStatus: string; demoTimerTab: string; demoSecure: string;
  benefitsEyebrow: string; benefitsTitle: string; benefit1: string; benefit1Body: string; benefit2: string; benefit2Body: string; benefit3: string; benefit3Body: string;
  flowEyebrow: string; flowTitle: string; step1: string; step1Body: string; step2: string; step2Body: string; step3: string; step3Body: string;
  privacyEyebrow: string; privacyTitle: string; privacyBody: string; privacyPoint1: string; privacyPoint2: string; privacyPoint3: string;
  connectEyebrow: string; connectTitle: string; connectBody: string; buildBooking: string;
};

const COPY: Record<SiteLocale, Copy> = {
  ru: {
    eyebrow: "IUMRAH BOOKING STATUS · TELEGRAM", titleA: "Бронь меняется.", titleB: "Telegram сообщает первым.", lead: "Статусы, серверные дедлайны, оплата, билеты и документы — без постоянного обновления страницы и без повторного входа в аккаунт.", primary: "Подключить мою бронь", noBooking: "Сначала создайте бронь в iumrah — после этого Telegram подключается одним нажатием.",
    demoKicker: "ЖИВОЙ СТАТУС", demoTitle: "Проверяем доступность", demoBody: "iumrah проверяет рейсы, отели и остальные компоненты вашей поездки.", demoTimer: "До следующего этапа", demoRef: "Бронь #0047", demoStatus: "Статус", demoTimerTab: "Таймер", demoSecure: "Защищено",
    benefitsEyebrow: "НЕ НУЖНО СЛЕДИТЬ ЗА СТРАНИЦЕЙ", benefitsTitle: "Iumrah сам приходит к Вам.", benefit1: "Статус в реальном времени", benefit1Body: "Telegram показывает тот же статус, который видят iOS, Android и Web из единой booking-системы.", benefit2: "Живые таймеры", benefit2Body: "Видно, сколько осталось на проверку наличия, фиксацию цены, подтверждение оплаты или подготовку документов.", benefit3: "События, которые нельзя пропустить", benefit3Body: "Оплата получена, бронь подтверждена, билет готов, изменился рейс — важные события приходят сообщением.",
    flowEyebrow: "ОДНА ПРИВЯЗКА", flowTitle: "Подключается за несколько секунд.", step1: "Создайте бронь", step1Body: "После успешного бронирования iumrah уже знает защищённый номер поездки.", step2: "Нажмите «Подключить Telegram»", step2Body: "Мы создаём одноразовую ссылку, действующую только 10 минут.", step3: "Получайте обновления", step3Body: "После привязки Telegram узнаёт Вашу бронь сам — логин и пароль больше не нужны.",
    privacyEyebrow: "ПРИВАТНОСТЬ ПО УМОЛЧАНИЮ", privacyTitle: "Telegram не становится второй базой iumrah.", privacyBody: "Бронь остаётся в единой iumrah-системе. Telegram получает только защищённую привязку к конкретной поездке и запрашивает актуальное состояние у сервера.", privacyPoint1: "Одноразовая ссылка на 10 минут", privacyPoint2: "Токен брони не хранится открытым", privacyPoint3: "Статус всегда берётся из единого сервера iumrah",
    connectEyebrow: "ГОТОВО К ПОДКЛЮЧЕНИЮ", connectTitle: "У Вас уже есть бронь?", connectBody: "Подключите её сейчас. После перехода Telegram закрепит эту поездку за Вашим аккаунтом.", buildBooking: "Собрать и создать бронь",
  },
  en: {
    eyebrow: "IUMRAH BOOKING STATUS · TELEGRAM", titleA: "Your booking changes.", titleB: "Telegram tells you first.", lead: "Statuses, server deadlines, payments, tickets and documents — without refreshing a page or signing in again.", primary: "Connect my booking", noBooking: "Create a booking in iumrah first. Telegram can then be linked in one tap.",
    demoKicker: "LIVE STATUS", demoTitle: "Checking availability", demoBody: "iumrah is checking flights, hotels and the other components of your journey.", demoTimer: "Until the next stage", demoRef: "Booking #0047", demoStatus: "Status", demoTimerTab: "Timer", demoSecure: "Secure",
    benefitsEyebrow: "NO NEED TO WATCH A PAGE", benefitsTitle: "Iumrah comes to you.", benefit1: "Live booking status", benefit1Body: "Telegram shows the same status seen by iOS, Android and Web from the single booking system.", benefit2: "Live timers", benefit2Body: "See how much time remains for availability, price lock, payment confirmation or document preparation.", benefit3: "Events you should not miss", benefit3Body: "Payment received, booking confirmed, ticket ready or flight changed — important events arrive as messages.",
    flowEyebrow: "ONE-TIME LINK", flowTitle: "Connected in a few seconds.", step1: "Create the booking", step1Body: "After a successful booking, iumrah already has the protected trip reference.", step2: "Tap “Connect Telegram”", step2Body: "We create a one-time link that stays valid for only 10 minutes.", step3: "Receive updates", step3Body: "Once linked, Telegram recognizes the booking automatically — no login or password is needed again.",
    privacyEyebrow: "PRIVATE BY DEFAULT", privacyTitle: "Telegram does not become a second iumrah database.", privacyBody: "Your booking stays inside the single iumrah system. Telegram receives a protected link to one trip and asks the server for the current state.", privacyPoint1: "One-time 10-minute link", privacyPoint2: "Booking token is never stored in plain text", privacyPoint3: "Status always comes from the single iumrah server",
    connectEyebrow: "READY TO CONNECT", connectTitle: "Already have a booking?", connectBody: "Link it now. After the handoff, Telegram attaches this trip to your Telegram account.", buildBooking: "Build and create a booking",
  },
  uz: {
    eyebrow: "IUMRAH BOOKING STATUS · TELEGRAM", titleA: "Bron o‘zgaradi.", titleB: "Telegram birinchi bo‘lib xabar beradi.", lead: "Holatlar, server muddatlari, to‘lov, biletlar va hujjatlar — sahifani doim yangilamasdan va akkauntga qayta kirmasdan.", primary: "Bronimni ulash", noBooking: "Avval iumrah’da bron yarating. Shundan keyin Telegram bir bosishda ulanadi.",
    demoKicker: "JONLI HOLAT", demoTitle: "Mavjudlik tekshirilmoqda", demoBody: "iumrah reyslar, mehmonxonalar va safarning boshqa qismlarini tekshirmoqda.", demoTimer: "Keyingi bosqichgacha", demoRef: "Bron #0047", demoStatus: "Holat", demoTimerTab: "Taymer", demoSecure: "Himoyalangan",
    benefitsEyebrow: "SAHIFANI KUZATIB O‘TIRISH SHART EMAS", benefitsTitle: "Iumrah o‘zi sizga keladi.", benefit1: "Real vaqtdagi bron holati", benefit1Body: "Telegram iOS, Android va Web ko‘radigan yagona booking tizimidagi aynan o‘sha holatni ko‘rsatadi.", benefit2: "Jonli taymerlar", benefit2Body: "Mavjudlik, narxni ushlab turish, to‘lov tasdig‘i yoki hujjatlar tayyorligigacha qancha vaqt qolganini ko‘ring.", benefit3: "O‘tkazib yuborib bo‘lmaydigan voqealar", benefit3Body: "To‘lov olindi, bron tasdiqlandi, bilet tayyor yoki reys o‘zgardi — muhim xabarlar Telegram’ga keladi.",
    flowEyebrow: "BIR MARTALIK ULANISH", flowTitle: "Bir necha soniyada ulanadi.", step1: "Bron yarating", step1Body: "Muvaffaqiyatli brondan so‘ng iumrah himoyalangan safar raqamini allaqachon biladi.", step2: "«Telegram’ni ulash»ni bosing", step2Body: "Faqat 10 daqiqa amal qiladigan bir martalik havola yaratamiz.", step3: "Yangilanishlarni oling", step3Body: "Ulangandan keyin Telegram bronni o‘zi taniydi — login va parol boshqa kerak emas.",
    privacyEyebrow: "MAXFIYLIK — ASOSIY TAMOYIL", privacyTitle: "Telegram iumrah’ning ikkinchi bazasiga aylanmaydi.", privacyBody: "Bron yagona iumrah tizimida qoladi. Telegram faqat bitta safarga himoyalangan bog‘lanish oladi va dolzarb holatni serverdan so‘raydi.", privacyPoint1: "10 daqiqalik bir martalik havola", privacyPoint2: "Bron tokeni ochiq ko‘rinishda saqlanmaydi", privacyPoint3: "Holat har doim yagona iumrah serveridan olinadi",
    connectEyebrow: "ULASHGA TAYYOR", connectTitle: "Sizda bron bormi?", connectBody: "Uni hozir ulang. Telegram shu safarni akkauntingizga biriktiradi.", buildBooking: "Umra tuzish va bron yaratish",
  },
  "uz-Cyrl": {
    eyebrow: "IUMRAH BOOKING STATUS · TELEGRAM", titleA: "Брон ўзгаради.", titleB: "Telegram биринчи бўлиб хабар беради.", lead: "Ҳолатлар, сервер муддатлари, тўлов, билетлар ва ҳужжатлар — саҳифани доим янгиламасдан ва аккаунтга қайта кирмасдан.", primary: "Бронимни улаш", noBooking: "Аввал iumrah’да брон яратинг. Шундан кейин Telegram бир босишда уланади.",
    demoKicker: "ЖОНЛИ ҲОЛАТ", demoTitle: "Мавжудлик текширилмоқда", demoBody: "iumrah рейслар, меҳмонхоналар ва сафарнинг бошқа қисмларини текширмоқда.", demoTimer: "Кейинги босқичгача", demoRef: "Брон #0047", demoStatus: "Ҳолат", demoTimerTab: "Таймер", demoSecure: "Ҳимояланган",
    benefitsEyebrow: "САҲИФАНИ КУЗАТИБ ЎТИРИШ ШАРТ ЭМАС", benefitsTitle: "Iumrah ўзи сизга келади.", benefit1: "Реал вақтдаги брон ҳолати", benefit1Body: "Telegram iOS, Android ва Web кўрадиган ягона booking тизимидаги айнан ўша ҳолатни кўрсатади.", benefit2: "Жонли таймерлар", benefit2Body: "Мавжудлик, нархни ушлаб туриш, тўлов тасдиғи ёки ҳужжатлар тайёрлигигача қанча вақт қолганини кўринг.", benefit3: "Ўтказиб юбориб бўлмайдиган воқеалар", benefit3Body: "Тўлов олинди, брон тасдиқланди, билет тайёр ёки рейс ўзгарди — муҳим хабарлар Telegram’га келади.",
    flowEyebrow: "БИР МАРТАЛИК УЛАНИШ", flowTitle: "Бир неча сонияда уланади.", step1: "Брон яратинг", step1Body: "Муваффақиятли брондан сўнг iumrah ҳимояланган сафар рақамини аллақачон билади.", step2: "«Telegram’ни улаш»ни босинг", step2Body: "Фақат 10 дақиқа амал қиладиган бир марталик ҳавола яратамиз.", step3: "Янгиланишларни олинг", step3Body: "Улангандан кейин Telegram бронни ўзи танийди — логин ва пароль бошқа керак эмас.",
    privacyEyebrow: "МАХФИЙЛИК — АСОСИЙ ТАМОЙИЛ", privacyTitle: "Telegram iumrah’нинг иккинчи базасига айланмайди.", privacyBody: "Брон ягона iumrah тизимида қолади. Telegram фақат битта сафарга ҳимояланган боғланиш олади ва долзарб ҳолатни сервердан сўрайди.", privacyPoint1: "10 дақиқалик бир марталик ҳавола", privacyPoint2: "Брон токени очиқ кўринишда сақланмайди", privacyPoint3: "Ҳолат ҳар доим ягона iumrah серверидан олинади",
    connectEyebrow: "УЛАШГА ТАЙЁР", connectTitle: "Сизда брон борми?", connectBody: "Уни ҳозир уланг. Telegram шу сафарни аккаунтингизга бириктиради.", buildBooking: "Умра тузиш ва брон яратиш",
  },
};

function useDemoTimer() {
  const initial = useMemo(() => (4 * 3600) + (31 * 60) + 27, []);
  const [seconds, setSeconds] = useState(initial);
  useEffect(() => {
    const timer = window.setInterval(() => setSeconds((value) => value > 0 ? value - 1 : initial), 1000);
    return () => window.clearInterval(timer);
  }, [initial]);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return [h, m, s].map((v) => String(v).padStart(2, "0")).join(":");
}

export function TelegramProductPage() {
  const { locale } = useSiteLocale();
  const t = COPY[locale];
  const [booking, setBooking] = useState<StoredWebBooking | null>(null);
  const timer = useDemoTimer();

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      setBooking(loadBooking());
    });
    return () => window.cancelAnimationFrame(frame);
  }, []);

  function scrollToConnect() {
    document.getElementById("telegram-connect")?.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  return (
    <main className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroCopy}>
          <span className={styles.eyebrow}>{t.eyebrow}</span>
          <h1><span>{t.titleA}</span><strong>{t.titleB}</strong></h1>
          <p>{t.lead}</p>
          <button type="button" className={styles.heroCta} onClick={scrollToConnect}>{t.primary}<Symbol name="arrowRight" size={18} /></button>
        </div>

        <div className={styles.demoShell} aria-label="Telegram booking status preview">
          <div className={styles.demoTop}><span className={styles.demoAvatar}><Symbol name="message" size={21} /></span><div><strong>iumrah Booking Status</strong><small>Telegram bot</small></div><span className={styles.liveDot}>LIVE</span></div>
          <div className={styles.demoMessage}>
            <span>{t.demoKicker}</span>
            <strong>{t.demoTitle}</strong>
            <p>{t.demoBody}</p>
            <div className={styles.demoReference}><small>{t.demoRef}</small><span>{t.demoTimer}</span></div>
            <div className={styles.demoTimer}>{timer}</div>
          </div>
          <div className={styles.demoTabs}><span><Symbol name="waveform" size={16} />{t.demoStatus}</span><span><Symbol name="calendar" size={16} />{t.demoTimerTab}</span><span><Symbol name="lock" size={16} />{t.demoSecure}</span></div>
        </div>
      </section>

      <section className={styles.section}>
        <span className={styles.eyebrow}>{t.benefitsEyebrow}</span>
        <h2>{t.benefitsTitle}</h2>
        <div className={styles.benefitGrid}>
          <article><span><Symbol name="waveform" size={22} /></span><h3>{t.benefit1}</h3><p>{t.benefit1Body}</p></article>
          <article><span><Symbol name="calendar" size={22} /></span><h3>{t.benefit2}</h3><p>{t.benefit2Body}</p></article>
          <article><span><Symbol name="message" size={22} /></span><h3>{t.benefit3}</h3><p>{t.benefit3Body}</p></article>
        </div>
      </section>

      <section className={`${styles.section} ${styles.flowSection}`}>
        <span className={styles.eyebrow}>{t.flowEyebrow}</span>
        <h2>{t.flowTitle}</h2>
        <div className={styles.flowGrid}>
          <article><b>01</b><h3>{t.step1}</h3><p>{t.step1Body}</p></article>
          <article><b>02</b><h3>{t.step2}</h3><p>{t.step2Body}</p></article>
          <article><b>03</b><h3>{t.step3}</h3><p>{t.step3Body}</p></article>
        </div>
      </section>

      <section className={`${styles.section} ${styles.privacy}`}>
        <div><span className={styles.eyebrow}>{t.privacyEyebrow}</span><h2>{t.privacyTitle}</h2><p>{t.privacyBody}</p></div>
        <div className={styles.privacyList}>
          <span><Symbol name="check" size={16} />{t.privacyPoint1}</span>
          <span><Symbol name="check" size={16} />{t.privacyPoint2}</span>
          <span><Symbol name="check" size={16} />{t.privacyPoint3}</span>
        </div>
      </section>

      <section className={styles.connectSection} id="telegram-connect">
        <div className={styles.connectIntro}><span className={styles.eyebrow}>{t.connectEyebrow}</span><h2>{t.connectTitle}</h2><p>{booking ? t.connectBody : t.noBooking}</p></div>
        {booking ? (
          <TelegramConnectCard bookingId={booking.id} bookingToken={booking.accessToken} bookingLabel={booking.bookingDisplayNumber ?? booking.id} locale={locale} showDetailsLink={false} />
        ) : (
          <Link href="/generator" className={styles.buildLink}>{t.buildBooking}<Symbol name="arrowRight" size={18} /></Link>
        )}
      </section>
    </main>
  );
}
