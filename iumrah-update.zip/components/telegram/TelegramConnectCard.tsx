"use client";

import Link from "next/link";
import { useState } from "react";
import { Symbol } from "@/components/design/Symbol";
import type { SiteLocale } from "@/lib/site-i18n";
import styles from "./TelegramConnectCard.module.css";

type Props = {
  bookingId: string;
  bookingToken: string;
  locale: SiteLocale;
  bookingLabel?: string | null;
  compact?: boolean;
  disabled?: boolean;
  showDetailsLink?: boolean;
};

type Copy = {
  eyebrow: string;
  title: string;
  body: string;
  status: string;
  timers: string;
  alerts: string;
  noLogin: string;
  button: string;
  loading: string;
  disabled: string;
  error: string;
  note: string;
  details: string;
};

const COPY: Record<SiteLocale, Copy> = {
  ru: {
    eyebrow: "IUMRAH BOOKING STATUS · TELEGRAM",
    title: "Ваша бронь — прямо в Telegram.",
    body: "Подключите бронь один раз и получайте изменения статуса, серверные таймеры, подтверждение оплаты, готовность билетов и документов без повторного входа на сайт.",
    status: "Статус поездки в реальном времени",
    timers: "Живые таймеры каждого этапа",
    alerts: "Уведомления о важных изменениях",
    noLogin: "Без логинов и паролей после подключения",
    button: "Подключить Telegram",
    loading: "Создаём защищённую ссылку…",
    disabled: "Подготавливаем бронь к подключению…",
    error: "Не удалось создать ссылку. Попробуйте ещё раз через несколько секунд.",
    note: "Одноразовая ссылка действует 10 минут. Telegram получает доступ только к этой брони.",
    details: "Как работает iUmrah Booking Status",
  },
  en: {
    eyebrow: "IUMRAH BOOKING STATUS · TELEGRAM",
    title: "Your booking, right inside Telegram.",
    body: "Link the booking once and receive status changes, server timers, payment confirmation, ticket readiness and document updates without signing in again.",
    status: "Live trip status",
    timers: "Live timers for every stage",
    alerts: "Alerts for important changes",
    noLogin: "No logins or passwords after linking",
    button: "Connect Telegram",
    loading: "Creating a secure link…",
    disabled: "Preparing your booking for Telegram…",
    error: "We could not create the link. Try again in a few seconds.",
    note: "The one-time link is valid for 10 minutes. Telegram only receives access to this booking.",
    details: "How iUmrah Booking Status works",
  },
  uz: {
    eyebrow: "IUMRAH BOOKING STATUS · TELEGRAM",
    title: "Broningiz — to‘g‘ridan-to‘g‘ri Telegram ichida.",
    body: "Bronni bir marta ulang va saytga qayta kirmasdan holat o‘zgarishlari, server taymerlari, to‘lov tasdig‘i, biletlar va hujjatlar tayyorligi haqida xabar oling.",
    status: "Safar holati real vaqtda",
    timers: "Har bir bosqich uchun jonli taymer",
    alerts: "Muhim o‘zgarishlar haqida bildirishnoma",
    noLogin: "Ulangandan keyin login va parol kerak emas",
    button: "Telegram’ni ulash",
    loading: "Himoyalangan havola yaratilmoqda…",
    disabled: "Bron Telegram uchun tayyorlanmoqda…",
    error: "Havola yaratilmadi. Bir necha soniyadan keyin yana urinib ko‘ring.",
    note: "Bir martalik havola 10 daqiqa amal qiladi. Telegram faqat shu bronga kirish oladi.",
    details: "iUmrah Booking Status qanday ishlaydi",
  },
  "uz-Cyrl": {
    eyebrow: "IUMRAH BOOKING STATUS · TELEGRAM",
    title: "Бронингиз — тўғридан-тўғри Telegram ичида.",
    body: "Бронни бир марта уланг ва сайтга қайта кирмасдан ҳолат ўзгаришлари, сервер таймерлари, тўлов тасдиғи, билетлар ва ҳужжатлар тайёрлиги ҳақида хабар олинг.",
    status: "Сафар ҳолати реал вақтда",
    timers: "Ҳар бир босқич учун жонли таймер",
    alerts: "Муҳим ўзгаришлар ҳақида билдиришнома",
    noLogin: "Улангандан кейин логин ва пароль керак эмас",
    button: "Telegram’ни улаш",
    loading: "Ҳимояланган ҳавола яратилмоқда…",
    disabled: "Брон Telegram учун тайёрланмоқда…",
    error: "Ҳавола яратилмади. Бир неча сониядан кейин яна уриниб кўринг.",
    note: "Бир марталик ҳавола 10 дақиқа амал қилади. Telegram фақат шу бронга кириш олади.",
    details: "iUmrah Booking Status қандай ишлайди",
  },
};

export function TelegramConnectCard({ bookingId, bookingToken, locale, bookingLabel, compact = false, disabled = false, showDetailsLink = true }: Props) {
  const copy = COPY[locale];
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function connect() {
    if (loading || disabled) return;
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/telegram/link", {
        method: "POST",
        headers: { "content-type": "application/json", "x-booking-token": bookingToken },
        body: JSON.stringify({ bookingId, language: locale }),
      });
      const payload = await response.json() as { linkUrl?: string | null; error?: string };
      if (!response.ok || !payload.linkUrl) throw new Error(payload.error || "TELEGRAM_LINK_FAILED");
      window.location.assign(payload.linkUrl);
    } catch {
      setError(copy.error);
      setLoading(false);
    }
  }

  return (
    <section className={styles.card} data-compact={compact ? "true" : "false"}>
      <div className={styles.glow} aria-hidden="true" />
      <div className={styles.topline}>
        <span className={styles.icon}><Symbol name="message" size={21} /></span>
        <span className={styles.eyebrow}>{copy.eyebrow}</span>
        {bookingLabel ? <span className={styles.booking}>{bookingLabel}</span> : null}
      </div>

      <div className={styles.copy}>
        <h2>{copy.title}</h2>
        <p>{copy.body}</p>
      </div>

      <div className={styles.features}>
        <span><Symbol name="waveform" size={17} />{copy.status}</span>
        <span><Symbol name="calendar" size={17} />{copy.timers}</span>
        <span><Symbol name="message" size={17} />{copy.alerts}</span>
        <span><Symbol name="lock" size={17} />{copy.noLogin}</span>
      </div>

      <div className={styles.actionRow}>
        <button type="button" className={styles.connectButton} onClick={connect} disabled={loading || disabled}>
          <span>{disabled ? copy.disabled : loading ? copy.loading : copy.button}</span>
          {!loading && !disabled ? <Symbol name="arrowRight" size={18} /> : null}
        </button>
        <div className={styles.actionMeta}><small>{copy.note}</small>{showDetailsLink ? <Link href="/telegram">{copy.details}<Symbol name="chevronRight" size={14} /></Link> : null}</div>
      </div>
      {error ? <div className={styles.error} role="status">{error}</div> : null}
    </section>
  );
}
