"use client";

import Link from "next/link";
import { useEffect, useState, type ReactNode } from "react";
import { Symbol, type SymbolName } from "@/components/design/Symbol";
import { useSiteLocale } from "@/components/site/SiteLocaleProvider";
import { TelegramConnectCard } from "@/components/telegram/TelegramConnectCard";
import type { SiteLocale } from "@/lib/site-i18n";
import {
  buildGeneratorTrace,
  clearPackageDraft,
  formatMoney,
  formatTripDate,
  hotelStarsForTier,
  loadBooking,
  loadPackageDraft,
  reconcileStoredBooking,
  saveBooking,
  type BookingContactProfile,
  type StoredWebBooking,
  type WebPackageDraft,
} from "@/lib/web-package";
import styles from "./BookingClient.module.css";

type Copy = {
  kicker: string; titleA: string; titleB: string; subtitle: string; packageLabel: string; pilgrims: string; pilgrim: string;
  serverVerified: string; total: string; perPerson: string; outbound: string; inbound: string; makkah: string; madinah: string; nights: string; room: string;
  paymentTitle: string; paymentKicker: string; paymentBody: string; invoice: string; receipt: string; paymentProtection: string; paymentProtectionBody: string;
  refundTitle: string; refundBody: string; nextTitle: string; next: string[]; tripTitle: string; tripSubtitle: string;
  flights: string; hotels: string; transfer: string; meals: string; care: string; travelers: string; included: string; notIncluded: string;
  cta: string; ctaLoading: string; legal: string; profileTitle: string; profileBody: string; profileSection: string; firstName: string; lastName: string; telegram: string; whatsapp: string; save: string; close: string;
  emptyKicker: string; emptyTitle: string; emptyBody: string; buildTrip: string; successKicker: string; successTitle: string; successBody: string; newPackage: string; booking: string; syncing: string;
  createError: string; syncWarning: string; bookingId: string; flightFare: string; hotelFare: string; transferRefund: string; servicesRefund: string;
};

const COPY: Record<SiteLocale, Copy> = {
  ru: {
    kicker: "FINAL REVIEW · IUMRAH BOOKING", titleA: "Проверим", titleB: "Вашу поездку.", subtitle: "Перед подтверждением iumrah ещё раз проверит доступность выбранного отеля и перелётов.", packageLabel: "ПАКЕТ УМРЫ", pilgrims: "паломников", pilgrim: "паломник",
    serverVerified: "Проверено сервером", total: "Итого за пакет", perPerson: "на человека", outbound: "Туда", inbound: "Обратно", makkah: "Мекка", madinah: "Медина", nights: "ноч.", room: "Номер",
    paymentTitle: "Временная ручная оплата", paymentKicker: "ПЕРВЫЕ 35 ДНЕЙ ЗАПУСКА", paymentBody: "Платёжный провайдер проходит серверное подключение и будет включён в следующем обновлении. Пока оплата выполняется вручную только по реквизитам внутри Вашего бронирования.", invoice: "Инвойс", receipt: "Чек", paymentProtection: "Как защищена ручная оплата", paymentProtectionBody: "Реквизиты и сумма отображаются только внутри созданного бронирования. Инвойс и подтверждение платежа сохраняются вместе с поездкой и доступны iumrah Care.",
    refundTitle: "Возврат Umrah-пакета", refundBody: "Каждый компонент рассчитывается отдельно по своим условиям.", nextTitle: "Что произойдёт дальше", next: ["Поездка получит защищённый номер", "Начнётся проверка доступности", "Статус появится во вкладке «Бронирование»", "Чат iumrah Care будет связан с этой поездкой"], tripTitle: "Вся поездка перед Вами", tripSubtitle: "Это именно та конфигурация, которая будет записана в бронирование.",
    flights: "Прямые рейсы", hotels: "Отели", transfer: "Приватный трансфер", meals: "Питание", care: "iumrah Care", travelers: "Паломники", included: "Включено", notIncluded: "Не выбрано",
    cta: "Проверить и создать бронирование", ctaLoading: "Создаём бронирование…", legal: "Оплата и паспортные данные оформляются отдельным защищённым этапом после создания бронирования.", profileTitle: "Данные паломника", profileBody: "Перед бронированием добавьте имя, фамилию и хотя бы один контакт, чтобы поддержка видела, кто именно оформляет поездку.", profileSection: "Профиль", firstName: "Имя", lastName: "Фамилия", telegram: "Telegram", whatsapp: "WhatsApp", save: "Сохранить и продолжить", close: "Закрыть",
    emptyKicker: "IUMRAH BOOKING", emptyTitle: "Здесь появится Ваша поездка.", emptyBody: "Сначала соберите пакет с прямыми рейсами. Затем здесь можно проверить его и создать бронирование.", buildTrip: "Собрать Умру", successKicker: "ПОЕЗДКА СОЗДАНА", successTitle: "Бронь закреплена.", successBody: "iumrah проверяет доступность. Статус поездки и чат поддержки уже связаны с этим бронированием.", newPackage: "Новый пакет", booking: "Бронь", syncing: "Синхронизируем защищённый отчёт…",
    createError: "Не удалось создать бронирование. Проверьте соединение и попробуйте ещё раз.", syncWarning: "Бронь сохранена. Синхронизация отчёта продолжится автоматически.", bookingId: "Номер бронирования", flightFare: "Авиабилеты — по правилам выбранного тарифа авиакомпании.", hotelFare: "Отели — по условиям выбранного тарифа номера.", transferRefund: "Трансфер — полный возврат при отмене минимум за 120 часов; позже применяется сбор.", servicesRefund: "Неиспользованные iumrah Services возвращаются до начала соответствующей услуги.",
  },
  en: {
    kicker: "FINAL REVIEW · IUMRAH BOOKING", titleA: "Let’s verify", titleB: "your trip.", subtitle: "Before confirmation, iumrah checks availability for your selected hotel and flights one more time.", packageLabel: "UMRAH PACKAGE", pilgrims: "pilgrims", pilgrim: "pilgrim",
    serverVerified: "Server verified", total: "Package total", perPerson: "per person", outbound: "Outbound", inbound: "Return", makkah: "Makkah", madinah: "Madinah", nights: "nights", room: "Room",
    paymentTitle: "Temporary manual payment", paymentKicker: "FIRST 35 DAYS AFTER LAUNCH", paymentBody: "The payment provider is undergoing server integration and will be enabled in the next update. Until then, payment is made manually only using the details inside your booking.", invoice: "Invoice", receipt: "Receipt", paymentProtection: "How manual payment is protected", paymentProtectionBody: "Payment details and the exact amount are shown only inside the created booking. The invoice and receipt stay attached to the trip and visible to iumrah Care.",
    refundTitle: "Umrah package refund", refundBody: "Each component follows its own refund terms.", nextTitle: "What happens next", next: ["Your trip gets a protected booking ID", "Availability checking starts", "Status appears in Booking", "iumrah Care chat links to this trip"], tripTitle: "Your complete trip", tripSubtitle: "This exact configuration will be written into the booking.",
    flights: "Direct flights", hotels: "Hotels", transfer: "Private transfer", meals: "Meals", care: "iumrah Care", travelers: "Pilgrims", included: "Included", notIncluded: "Not selected",
    cta: "Review and create booking", ctaLoading: "Creating booking…", legal: "Payment and passport details are handled in a separate secure step after the booking is created.", profileTitle: "Pilgrim details", profileBody: "Before booking, please add your first name, last name and at least one contact so support can recognize the pilgrim.", profileSection: "Profile", firstName: "First name", lastName: "Last name", telegram: "Telegram", whatsapp: "WhatsApp", save: "Save and continue", close: "Close",
    emptyKicker: "IUMRAH BOOKING", emptyTitle: "Your trip will appear here.", emptyBody: "Build a package with direct flights first. Then you can review it here and create the booking.", buildTrip: "Build Umrah", successKicker: "TRIP CREATED", successTitle: "Booking secured.", successBody: "iumrah is checking availability. Your trip status and support chat are now linked to this booking.", newPackage: "New package", booking: "Booking", syncing: "Syncing protected booking report…",
    createError: "Could not create the booking. Check your connection and try again.", syncWarning: "Booking saved. Report synchronization will continue automatically.", bookingId: "Booking ID", flightFare: "Flights follow the rules of the selected airline fare.", hotelFare: "Hotels follow the selected room-rate terms.", transferRefund: "Transfer is fully refundable at least 120 hours before pickup; a fee applies later.", servicesRefund: "Unused iumrah Services are refundable before the relevant service starts.",
  },
  uz: {
    kicker: "FINAL REVIEW · IUMRAH BOOKING", titleA: "Safaringizni", titleB: "tekshiramiz.", subtitle: "Tasdiqlashdan oldin iumrah tanlangan mehmonxona va parvozlar mavjudligini yana bir bor tekshiradi.", packageLabel: "UMRA PAKETI", pilgrims: "ziyoratchi", pilgrim: "ziyoratchi",
    serverVerified: "Serverda tekshirildi", total: "Paket jami", perPerson: "bir kishiga", outbound: "Borish", inbound: "Qaytish", makkah: "Makka", madinah: "Madina", nights: "tun", room: "Xona",
    paymentTitle: "Vaqtinchalik qo‘lda to‘lov", paymentKicker: "ISHGA TUSHGANDAN KEYINGI DASTLABKI 35 KUN", paymentBody: "To‘lov provayderi serverga ulanmoqda va keyingi yangilanishda yoqiladi. Hozircha to‘lov faqat broningiz ichidagi rekvizitlar bo‘yicha qo‘lda amalga oshiriladi.", invoice: "Invoice", receipt: "Chek", paymentProtection: "Qo‘lda to‘lov qanday himoyalanadi", paymentProtectionBody: "Rekvizitlar va aniq summa faqat yaratilgan bron ichida ko‘rsatiladi. Invoice va chek safarga biriktiriladi va iumrah Care uchun ko‘rinadi.",
    refundTitle: "Umra paketi qaytarilishi", refundBody: "Har bir komponent o‘z shartlari bo‘yicha hisoblanadi.", nextTitle: "Keyin nima bo‘ladi", next: ["Safarga himoyalangan bron raqami beriladi", "Mavjudlik tekshiruvi boshlanadi", "Holat Bron bo‘limida paydo bo‘ladi", "iumrah Care chati shu safarga ulanadi"], tripTitle: "Butun safaringiz", tripSubtitle: "Aynan shu konfiguratsiya bron ichiga yoziladi.",
    flights: "To‘g‘ridan-to‘g‘ri reyslar", hotels: "Mehmonxonalar", transfer: "Shaxsiy transfer", meals: "Ovqatlanish", care: "iumrah Care", travelers: "Ziyoratchilar", included: "Kiritilgan", notIncluded: "Tanlanmagan",
    cta: "Tekshirish va bron yaratish", ctaLoading: "Bron yaratilmoqda…", legal: "To‘lov va pasport ma’lumotlari bron yaratilgandan keyin alohida himoyalangan bosqichda rasmiylashtiriladi.", profileTitle: "Ziyoratchi ma’lumotlari", profileBody: "Bron qilishdan oldin ism, familiya va kamida bitta kontaktni kiriting, shunda yordam jamoasi ziyoratchini taniydi.", profileSection: "Profil", firstName: "Ism", lastName: "Familiya", telegram: "Telegram", whatsapp: "WhatsApp", save: "Saqlash va davom etish", close: "Yopish",
    emptyKicker: "IUMRAH BOOKING", emptyTitle: "Safaringiz shu yerda paydo bo‘ladi.", emptyBody: "Avval to‘g‘ridan-to‘g‘ri reyslar bilan paket tuzing. Keyin uni shu yerda tekshirib bron yaratasiz.", buildTrip: "Umra tuzish", successKicker: "SAFAR YARATILDI", successTitle: "Bron saqlandi.", successBody: "iumrah mavjudlikni tekshirmoqda. Safar holati va yordam chati shu bronga ulandi.", newPackage: "Yangi paket", booking: "Bron", syncing: "Himoyalangan hisobot sinxronlanmoqda…",
    createError: "Bron yaratilmadi. Internet aloqasini tekshirib, yana urinib ko‘ring.", syncWarning: "Bron saqlandi. Hisobot sinxronlanishi avtomatik davom etadi.", bookingId: "Bron raqami", flightFare: "Reyslar tanlangan aviakompaniya tarifi qoidalariga bog‘liq.", hotelFare: "Mehmonxona tanlangan xona tarifi shartlariga bog‘liq.", transferRefund: "Transfer kamida 120 soat oldin bekor qilinsa to‘liq qaytariladi; keyin yig‘im qo‘llanadi.", servicesRefund: "Boshlanmagan iumrah Services qaytariladi.",
  },
  "uz-Cyrl": {
    kicker: "FINAL REVIEW · IUMRAH BOOKING", titleA: "Сафарингизни", titleB: "текширамиз.", subtitle: "Тасдиқлашдан олдин iumrah танланган отель ва парвозлар мавжудлигини яна бир бор текширади.", packageLabel: "УМРА ПАКЕТИ", pilgrims: "зиёратчи", pilgrim: "зиёратчи",
    serverVerified: "Серверда текширилди", total: "Пакет жами", perPerson: "бир кишига", outbound: "Бориш", inbound: "Қайтиш", makkah: "Макка", madinah: "Мадина", nights: "тун", room: "Хона",
    paymentTitle: "Вақтинчалик қўлда тўлов", paymentKicker: "ИШГА ТУШГАНДАН КЕЙИНГИ ДАСТЛАБКИ 35 КУН", paymentBody: "Тўлов провайдери серверга уланмоқда ва кейинги янгиланишда ёқилади. Ҳозирча тўлов фақат брон ичидаги реквизитлар бўйича қўлда амалга оширилади.", invoice: "Invoice", receipt: "Чек", paymentProtection: "Қўлда тўлов қандай ҳимояланади", paymentProtectionBody: "Реквизитлар ва аниқ сумма фақат яратилган брон ичида кўрсатилади. Invoice ва чек сафарга бириктирилади ва iumrah Care учун кўринади.",
    refundTitle: "Умра пакети қайтарилиши", refundBody: "Ҳар бир компонент ўз шартлари бўйича ҳисобланади.", nextTitle: "Кейин нима бўлади", next: ["Сафарга ҳимояланган брон рақами берилади", "Мавжудлик текшируви бошланади", "Ҳолат Брон бўлимида пайдо бўлади", "iumrah Care чати шу сафарга уланади"], tripTitle: "Бутун сафарингиз", tripSubtitle: "Айнан шу конфигурация брон ичига ёзилади.",
    flights: "Тўғридан-тўғри рейслар", hotels: "Меҳмонхоналар", transfer: "Шахсий трансфер", meals: "Овқатланиш", care: "iumrah Care", travelers: "Зиёратчилар", included: "Киритилган", notIncluded: "Танланмаган",
    cta: "Текшириш ва брон яратиш", ctaLoading: "Брон яратилмоқда…", legal: "Тўлов ва паспорт маълумотлари брон яратилгандан кейин алоҳида ҳимояланган босқичда расмийлаштирилади.", profileTitle: "Зиёратчи маълумотлари", profileBody: "Брон қилишдан олдин исм, фамилия ва камида битта контактни киритинг, шунда ёрдам жамоаси зиёратчини танийди.", profileSection: "Профиль", firstName: "Исм", lastName: "Фамилия", telegram: "Telegram", whatsapp: "WhatsApp", save: "Сақлаш ва давом этиш", close: "Ёпиш",
    emptyKicker: "IUMRAH BOOKING", emptyTitle: "Сафарингиз шу ерда пайдо бўлади.", emptyBody: "Аввал тўғридан-тўғри рейслар билан пакет тузинг. Кейин уни шу ерда текшириб брон яратасиз.", buildTrip: "Умра тузиш", successKicker: "САФАР ЯРАТИЛДИ", successTitle: "Брон сақланди.", successBody: "iumrah мавжудликни текширмоқда. Сафар ҳолати ва ёрдам чати шу бронга уланди.", newPackage: "Янги пакет", booking: "Брон", syncing: "Ҳимояланган ҳисобот синхронланмоқда…",
    createError: "Брон яратилмади. Интернет алоқасини текшириб, яна уриниб кўринг.", syncWarning: "Брон сақланди. Ҳисобот синхронланиши автоматик давом этади.", bookingId: "Брон рақами", flightFare: "Рейслар танланган авиакомпания тарифи қоидаларига боғлиқ.", hotelFare: "Меҳмонхона танланган хона тарифи шартларига боғлиқ.", transferRefund: "Трансфер камида 120 соат олдин бекор қилинса тўлиқ қайтарилади; кейин йиғим қўлланади.", servicesRefund: "Бошланмаган iumrah Services қайтарилади.",
  },
};

function bookingPayload(draft: WebPackageDraft, profile: BookingContactProfile, locale: SiteLocale) {
  const trace = buildGeneratorTrace(draft);
  const includesMadinah = draft.stay.madinahNights > 0;
  const flightName = [
    `${draft.journey.outbound.airline} ${draft.journey.outbound.flight_number}`.trim(),
    `${draft.journey.inbound.airline} ${draft.journey.inbound.flight_number}`.trim(),
  ].filter(Boolean).join(" / ");
  const includedServices = ["flight", "makkahHotel", "visa", "meals", "transfer", ...(draft.haramainEnabled ? ["haramainTrain"] : []), "accompaniment", "ziyaratMakkah", "care", "esim"];
  if (includesMadinah) includedServices.splice(2, 0, "madinahHotel");
  if (includesMadinah) includedServices.splice(includedServices.length - 2, 0, "ziyaratMadinah");

  return {
    lang: locale === "uz-Cyrl" ? "uz-cyrl" : locale,
    booking: {
      planId: draft.tier,
      totalUsd: draft.quote.totalPackagePrice,
      perPilgrimUsd: draft.quote.pricePerPerson,
      input: {
        from: draft.originCode,
        originCode: draft.originCode,
        arrivalAirportCode: draft.journey.outbound.destination,
        cabinClass: draft.journey.outbound.cabin_class.toLowerCase() === "business" ? "business" : "economy",
        preferredPlan: draft.tier,
        startDate: draft.stay.startDate,
        endDate: draft.stay.endDate,
        flexibleDays: 0,
        hotelPreference: String(hotelStarsForTier(draft.tier)),
        includeMadinah: includesMadinah,
        travelers: draft.travelers,
      },
      route: {
        originCode: draft.originCode,
        outboundDestination: draft.journey.outbound.destination,
        returnOrigin: draft.journey.inbound.origin,
      },
      stay: {
        totalDays: draft.stay.totalDays,
        totalNights: draft.stay.totalNights,
        makkahCheckIn: draft.stay.makkahCheckIn,
        makkahCheckOut: draft.stay.makkahCheckOut,
        makkahNights: draft.stay.makkahNights,
        madinahCheckIn: includesMadinah ? draft.stay.madinahCheckIn : null,
        madinahCheckOut: includesMadinah ? draft.stay.madinahCheckOut : null,
        madinahNights: includesMadinah ? draft.stay.madinahNights : 0,
      },
      selection: {
        flightId: `${draft.journey.outboundOfferId}|${draft.journey.inboundOfferId}`,
        makkahHotelId: draft.makkahHotel.id,
        madinahHotelId: includesMadinah ? draft.madinahHotel.id : null,
      },
      customization: {
        accompaniment: true,
        guideMeetingPoint: "airport",
        ziyaratMakkah: true,
        ziyaratMadinah: includesMadinah,
        meals: true,
        esim: true,
      },
      includedServices,
      hotelNames: { makkah: draft.makkahHotel.name, ...(includesMadinah ? { madinah: draft.madinahHotel.name } : {}) },
      flight: flightName,
      generatorTrace: trace,
      pilgrimProfile: profile,
    },
  };
}

function tierTitle(value: WebPackageDraft["tier"]) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function coverImage(draft: WebPackageDraft) {
  return draft.makkahHotel.images.find((image) => image.isCover)?.url ?? draft.makkahHotel.images[0]?.url ?? "/iumrah/mobile-reference/flights-showcase.jpeg";
}

function roomName(hotel: WebPackageDraft["makkahHotel"], roomId: string | null) {
  if (!roomId) return null;
  return hotel.rooms.find((room) => room.id === roomId)?.name ?? null;
}

export function BookingClient() {
  const { locale } = useSiteLocale();
  const t = COPY[locale];
  const [draft, setDraft] = useState<WebPackageDraft | null>(null);
  const [stored, setStored] = useState<StoredWebBooking | null>(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [telegram, setTelegram] = useState("");
  const [profileOpen, setProfileOpen] = useState(false);
  const [refundOpen, setRefundOpen] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [commitWarning, setCommitWarning] = useState("");

  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (cancelled) return;
      const currentDraft = loadPackageDraft();
      const currentBooking = loadBooking();
      setDraft(currentDraft);
      setStored(currentBooking);
      if (currentBooking?.profile) {
        setFirstName(currentBooking.profile.firstName || "");
        setLastName(currentBooking.profile.lastName || "");
        setWhatsapp(currentBooking.profile.whatsapp || "");
        setTelegram(currentBooking.profile.telegram || "");
      }
      if (currentBooking?.pendingQuoteProof) {
        void reconcileStoredBooking(currentBooking).then((result) => {
          if (cancelled) return;
          setStored(result.booking);
          if (!result.commitOk || !result.syncOk) setCommitWarning(t.syncWarning);
        });
      }
    });
    return () => { cancelled = true; };
  }, [t.syncWarning]);

  const valid = Boolean(firstName.trim() && lastName.trim() && (whatsapp.trim().length >= 6 || telegram.trim().length >= 2));

  async function submitBooking() {
    if (!draft || !valid || submitting) return;
    setProfileOpen(false);
    setSubmitting(true);
    setError("");
    setCommitWarning("");
    const profile: BookingContactProfile = { firstName: firstName.trim(), lastName: lastName.trim(), telegram: telegram.trim(), whatsapp: whatsapp.trim() };

    try {
      const response = await fetch("/api/bookings", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(bookingPayload(draft, profile, locale)) });
      const result = await response.json() as { booking?: { id?: string }; accessToken?: string; error?: string };
      const bookingId = result.booking?.id ?? "";
      const accessToken = result.accessToken ?? "";
      if (!response.ok || !bookingId || !accessToken) throw new Error(result.error || "BOOKING_CREATE_FAILED");

      const safeQuote = { totalPackagePrice: draft.quote.totalPackagePrice, pricePerPerson: draft.quote.pricePerPerson, currency: draft.quote.currency, isEstimated: draft.quote.isEstimated, quoteId: draft.quote.quoteId };
      const safeDraft: StoredWebBooking["draft"] = { ...draft, quote: safeQuote };
      const pending: StoredWebBooking = { id: bookingId, accessToken, createdAt: new Date().toISOString(), draft: safeDraft, profile, generatorTrace: buildGeneratorTrace(draft), pendingQuoteProof: draft.quote.quoteProof };
      saveBooking(pending);
      clearPackageDraft();
      setStored(pending);
      setDraft(null);

      const reconciled = await reconcileStoredBooking(pending);
      setStored(reconciled.booking);
      if (!reconciled.commitOk || !reconciled.syncOk) setCommitWarning(t.syncWarning);
    } catch (requestError) {
      const raw = requestError instanceof Error ? requestError.message : "";
      setError(raw && !raw.includes("BOOKING_") ? raw : t.createError);
    } finally {
      setSubmitting(false);
    }
  }

  if (!draft && !stored) {
    return <main className={styles.page}><section className={styles.stateCard}><span className={styles.stateIcon}><Symbol name="calendar" size={26} /></span><span className={styles.eyebrow}>{t.emptyKicker}</span><h1>{t.emptyTitle}</h1><p>{t.emptyBody}</p><Link href="/generator" className={styles.primaryLink}>{t.buildTrip}<Symbol name="chevronRight" size={16} /></Link></section></main>;
  }

  if (stored && !draft) {
    const medinahIncluded = stored.draft.stay.madinahNights > 0;
    return <main className={styles.page}><div className={styles.successStack}><section className={`${styles.stateCard} ${styles.successState}`}><span className={`${styles.stateIcon} ${styles.successIcon}`}><Symbol name="check" size={26} /></span><span className={styles.eyebrow}>{t.successKicker}</span><h1>{t.successTitle}</h1><p>{t.successBody}</p><div className={styles.bookingNumber}><small>{t.bookingId}</small><strong>{stored.bookingDisplayNumber ?? stored.id}</strong></div><div className={styles.successRoute}><span>{formatTripDate(stored.draft.journey.outbound.departure_at)} — {formatTripDate(stored.draft.journey.inbound.departure_at)}</span><strong>{stored.draft.originCode} → {stored.draft.journey.outbound.destination}{medinahIncluded ? " · MED" : ""} → {stored.draft.originCode}</strong></div><div className={styles.successPrice}>{formatMoney(stored.draft.quote.totalPackagePrice, stored.draft.quote.currency)}</div>{(stored.pendingQuoteProof || commitWarning) ? <div className={styles.warning}>{commitWarning || t.syncing}</div> : null}<div className={styles.stateActions}><Link href="/support" className={styles.primaryLink}>iumrah Care <Symbol name="message" size={16} /></Link><Link href="/generator" className={styles.secondaryLink}>{t.newPackage}</Link></div></section><TelegramConnectCard bookingId={stored.id} bookingToken={stored.accessToken} bookingLabel={stored.bookingDisplayNumber ?? stored.id} locale={locale} compact /></div></main>;
  }

  if (!draft) return null;

  const includesMadinah = draft.stay.madinahNights > 0;
  const makkahRoom = roomName(draft.makkahHotel, draft.makkahRoomId);
  const madinahRoom = includesMadinah ? roomName(draft.madinahHotel, draft.madinahRoomId) : null;
  const hero = coverImage(draft);

  return (
    <main className={styles.page}>
      <div className={styles.container}>
        <header className={styles.editorialHeader}>
          <span>{t.kicker}</span>
          <h1><em>{t.titleA}</em> <strong>{t.titleB}</strong></h1>
          <p>{t.subtitle}</p>
        </header>

        <section className={styles.checkoutSummary}>
          <div className={styles.checkoutSummaryHead}>
            <div>
              <small>{t.packageLabel}</small>
              <strong>{tierTitle(draft.tier)}</strong>
            </div>
            <span className={styles.verifiedBadge}><Symbol name="shield" size={13} />{t.serverVerified}</span>
          </div>

          <div className={styles.hotelSnapshot}>
            <span className={styles.hotelSnapshotImage} style={{ backgroundImage: `url("${hero.replace(/"/g, "%22")}")` }} />
            <div>
              <small>{t.makkah} · {draft.stay.makkahNights} {t.nights}</small>
              <strong>{draft.makkahHotel.name}</strong>
              {makkahRoom ? <span><Symbol name="bed" size={13} /> {makkahRoom}</span> : null}
            </div>
          </div>

          {includesMadinah ? <div className={styles.secondaryHotelSnapshot}><span className={styles.secondaryHotelIcon}><Symbol name="bed" size={17} /></span><div><small>{t.madinah} · {draft.stay.madinahNights} {t.nights}</small><strong>{draft.madinahHotel.name}</strong>{madinahRoom ? <span>{madinahRoom}</span> : null}</div></div> : null}

          <div className={styles.checkoutRoute}>
            <div><small>{t.outbound}</small><strong>{draft.originCode} → {draft.journey.outbound.destination}</strong><span>{formatTripDate(draft.journey.outbound.departure_at)} · {draft.journey.outbound.airline} {draft.journey.outbound.flight_number}</span></div>
            <span className={styles.routeIcon}><Symbol name="airplane" size={16} /></span>
            <div><small>{t.inbound}</small><strong>{draft.journey.inbound.origin} → {draft.originCode}</strong><span>{formatTripDate(draft.journey.inbound.departure_at)} · {draft.journey.inbound.airline} {draft.journey.inbound.flight_number}</span></div>
          </div>

          <div className={styles.checkoutTotal}>
            <div><small>{t.total}</small><strong>{formatMoney(draft.quote.totalPackagePrice, draft.quote.currency)}</strong></div>
            <span>{formatMoney(draft.quote.pricePerPerson, draft.quote.currency)} · {t.perPerson}</span>
          </div>
        </section>

        <section className={styles.paymentNotice}>
          <span className={styles.paymentIcon}><Symbol name="shield" size={18} /></span>
          <div>
            <small>{t.paymentKicker}</small>
            <h2>{t.paymentTitle}</h2>
            <p>{t.paymentBody}</p>
            <div className={styles.paymentChips}><span><Symbol name="creditCard" size={13} />{t.invoice}</span><span><Symbol name="check" size={13} />{t.receipt}</span></div>
            <button type="button" onClick={() => setPaymentOpen(true)}><span>{t.paymentProtection}</span><Symbol name="chevronRight" size={14} /></button>
          </div>
        </section>

        <button type="button" className={styles.policyCard} onClick={() => setRefundOpen(true)}>
          <span className={styles.policyIcon}><Symbol name="shield" size={18} /></span>
          <span><strong>{t.refundTitle}</strong><small>{t.refundBody}</small></span>
          <Symbol name="chevronRight" size={16} />
        </button>

        <section className={styles.sectionHeader}><span>IUMRAH · NEXT</span><h2>{t.nextTitle}</h2></section>
        <section className={styles.stepsCard}>{t.next.map((step, index) => <div key={step}><span>{String(index + 1).padStart(2, "0")}</span><p>{step}</p></div>)}</section>

        {error ? <div className={styles.error}>{error}</div> : null}
        {commitWarning ? <div className={styles.warning}>{commitWarning}</div> : null}

        <button type="button" className={styles.cta} disabled={submitting} onClick={() => setProfileOpen(true)}>{submitting ? <><span className={styles.spinner} />{t.ctaLoading}</> : <><span>{t.cta}</span><Symbol name="arrowRight" size={18} /></>}</button>
        <p className={styles.legal}>{t.legal}</p>
      </div>

      {refundOpen ? <RefundPolicySheet locale={locale} done={t.close} onClose={() => setRefundOpen(false)} /> : null}
      {paymentOpen ? <PaymentSecuritySheet locale={locale} t={t} onClose={() => setPaymentOpen(false)} /> : null}
      {profileOpen ? <ProfileCaptureSheet t={t} firstName={firstName} lastName={lastName} telegram={telegram} whatsapp={whatsapp} valid={valid} submitting={submitting} setFirstName={setFirstName} setLastName={setLastName} setTelegram={setTelegram} setWhatsapp={setWhatsapp} onClose={() => setProfileOpen(false)} onSubmit={() => void submitBooking()} /> : null}
    </main>
  );
}

type CheckoutPolicyPoint = { icon: SymbolName; title: string; badge?: string; body: string };

const CHECKOUT_POLICY_COPY: Record<SiteLocale, {
  refundTitle: string; refundSubtitle: string; refundRules: CheckoutPolicyPoint[]; termsTitle: string; termsBody: string;
  paymentTitle: string; paymentSubtitle: string; paymentRules: CheckoutPolicyPoint[];
}> = {
  ru: {
    refundTitle: "Политика возврата", refundSubtitle: "Каждый компонент поездки имеет собственные условия. iumrah показывает их до оплаты и применяет к конкретному бронированию.",
    refundRules: [
      { icon: "airplane", title: "Авиабилет", badge: "По умолчанию без возврата", body: "В базовый пакет включаются наиболее доступные тарифы. Возврат или изменение возможны только по правилам выбранного тарифа и авиакомпании." },
      { icon: "bed", title: "Отель", badge: "По умолчанию без возврата", body: "Базовая цена использует невозвратный тариф, если в выбранном варианте не указана бесплатная отмена. Точный срок и удержание показываются до оплаты." },
      { icon: "car", title: "Трансфер", badge: "Бесплатно до 5 дней", body: "При отмене не позднее чем за 120 часов до подачи автомобиля возвращается полная стоимость. Позже удерживается $100; после начала услуги возврата нет." },
      { icon: "heart", title: "Сервисы iumrah", badge: "Возврат до начала услуги", body: "Неиспользованные сервисы iumrah возвращаются полностью до начала соответствующей услуги. Начатая услуга считается использованной." },
    ],
    termsTitle: "Условия фиксируются при бронировании", termsBody: "Если конкретный тариф, отель или поставщик показывает другие условия, именно они имеют приоритет и отображаются перед оплатой. После подтверждения условия конкретного бронирования не ухудшаются задним числом.",
    paymentTitle: "Безопасность ручной оплаты", paymentSubtitle: "Реквизиты, инвойс и подтверждение платежа привязаны к конкретному бронированию.",
    paymentRules: [
      { icon: "numberCircle", title: "Реквизиты только внутри бронирования", body: "Оплачивайте только по реквизитам, которые показаны в защищённом экране вашего конкретного бронирования. Перед переводом проверьте номер брони, сумму и получателя." },
      { icon: "creditCard", title: "Инвойс и чек", body: "Инвойс формируется из данных конкретного бронирования. После ручной оплаты банковский чек прикрепляется к поездке и используется для сверки платежа." },
      { icon: "shield", title: "Никаких PIN и CVV", body: "iumrah не просит PIN, CVV/CVC или пароль от банковского приложения. Подтверждение оплаты хранится вместе с бронированием и доступно iumrah Care." },
    ],
  },
  en: {
    refundTitle: "Refund Policy", refundSubtitle: "Each travel component has its own terms. iumrah shows them before payment and applies them to your booking.",
    refundRules: [
      { icon: "airplane", title: "Flight", badge: "Non-refundable by default", body: "The base package uses the most affordable fares. Refunds or changes follow the selected fare and airline rules." },
      { icon: "bed", title: "Hotel", badge: "Non-refundable by default", body: "The base price uses a non-refundable hotel rate unless the selected option explicitly offers free cancellation. Exact deadlines and fees are shown before payment." },
      { icon: "car", title: "Transfer", badge: "Free until 5 days before", body: "Cancel at least 120 hours before pickup for a full refund. Later cancellations carry a $100 fee; after service begins there is no refund." },
      { icon: "heart", title: "iumrah services", badge: "Refundable before service starts", body: "Unused iumrah services are fully refundable before the relevant service starts. A started service is treated as used." },
    ],
    termsTitle: "Terms are fixed at booking", termsBody: "If a specific fare, hotel or supplier shows different terms, those terms take priority and are displayed before payment. Confirmed booking terms are not made worse retroactively.",
    paymentTitle: "Manual payment security", paymentSubtitle: "Payment details, invoice and proof are tied to the specific booking.",
    paymentRules: [
      { icon: "numberCircle", title: "Payment details stay inside the booking", body: "Pay only using details shown in the protected screen for your booking. Verify the booking reference, amount and recipient before transferring." },
      { icon: "creditCard", title: "Invoice and receipt", body: "The invoice is generated from the booking. After manual payment, the bank receipt is attached to the trip and used to reconcile the payment." },
      { icon: "shield", title: "No PIN or CVV requests", body: "iumrah never asks for your PIN, CVV/CVC or banking-app password. Payment proof remains attached to the booking and visible to iumrah Care." },
    ],
  },
  uz: {
    refundTitle: "Qaytarish siyosati", refundSubtitle: "Safarning har bir komponenti o‘z shartlariga ega. iumrah ularni to‘lovdan oldin ko‘rsatadi va broningizga qo‘llaydi.",
    refundRules: [
      { icon: "airplane", title: "Aviachipta", badge: "Odatda qaytarilmaydi", body: "Asosiy paket eng qulay tariflardan foydalanadi. Qaytarish yoki o‘zgartirish tanlangan tarif va aviakompaniya qoidalariga bog‘liq." },
      { icon: "bed", title: "Mehmonxona", badge: "Odatda qaytarilmaydi", body: "Tanlangan variantda bepul bekor qilish ko‘rsatilmagan bo‘lsa, asosiy narx qaytarilmaydigan tarifdan foydalanadi. Aniq muddat va yig‘im to‘lovdan oldin ko‘rsatiladi." },
      { icon: "car", title: "Transfer", badge: "5 kun oldin bepul", body: "Avtomobil kelishidan kamida 120 soat oldin bekor qilinsa to‘liq qaytariladi. Keyin $100 ushlab qolinadi; xizmat boshlanganidan keyin qaytarilmaydi." },
      { icon: "heart", title: "iumrah xizmatlari", badge: "Xizmat boshlanguncha qaytariladi", body: "Boshlanmagan iumrah xizmatlari to‘liq qaytariladi. Boshlangan xizmat ishlatilgan hisoblanadi." },
    ],
    termsTitle: "Shartlar bron paytida belgilanadi", termsBody: "Agar aniq tarif, mehmonxona yoki hamkor boshqa shartlarni ko‘rsatsa, ular ustuvor bo‘ladi va to‘lovdan oldin ko‘rsatiladi. Tasdiqlangan bron shartlari keyinchalik yomonlashtirilmaydi.",
    paymentTitle: "Qo‘lda to‘lov xavfsizligi", paymentSubtitle: "Rekvizitlar, invoice va to‘lov tasdig‘i aniq bron bilan bog‘langan.",
    paymentRules: [
      { icon: "numberCircle", title: "Rekvizitlar faqat bron ichida", body: "Faqat aniq broningizning himoyalangan sahifasida ko‘rsatilgan rekvizitlar bo‘yicha to‘lang. O‘tkazmadan oldin bron raqami, summa va qabul qiluvchini tekshiring." },
      { icon: "creditCard", title: "Invoice va chek", body: "Invoice bron ma’lumotlaridan yaratiladi. Qo‘lda to‘lovdan keyin bank cheki safarga biriktiriladi va to‘lovni tekshirish uchun ishlatiladi." },
      { icon: "shield", title: "PIN yoki CVV so‘ralmaydi", body: "iumrah PIN, CVV/CVC yoki bank ilovasi parolini so‘ramaydi. To‘lov tasdig‘i bron bilan saqlanadi va iumrah Care uchun ko‘rinadi." },
    ],
  },
  "uz-Cyrl": {
    refundTitle: "Қайтариш сиёсати", refundSubtitle: "Сафарнинг ҳар бир компоненти ўз шартларига эга. iumrah уларни тўловдан олдин кўрсатади ва бронга қўллайди.",
    refundRules: [
      { icon: "airplane", title: "Авиачипта", badge: "Одатда қайтарилмайди", body: "Асосий пакет энг қулай тарифлардан фойдаланади. Қайтариш ёки ўзгартириш танланган тариф ва авиакомпания қоидаларига боғлиқ." },
      { icon: "bed", title: "Меҳмонхона", badge: "Одатда қайтарилмайди", body: "Танланган вариантда бепул бекор қилиш кўрсатилмаган бўлса, асосий нарх қайтарилмайдиган тарифдан фойдаланади. Аниқ муддат ва йиғим тўловдан олдин кўрсатилади." },
      { icon: "car", title: "Трансфер", badge: "5 кун олдин бепул", body: "Автомобиль келишидан камида 120 соат олдин бекор қилинса тўлиқ қайтарилади. Кейин $100 ушлаб қолинади; хизмат бошланганидан кейин қайтарилмайди." },
      { icon: "heart", title: "iumrah хизматлари", badge: "Хизмат бошлангунча қайтарилади", body: "Бошланмаган iumrah хизматлари тўлиқ қайтарилади. Бошланган хизмат ишлатилган ҳисобланади." },
    ],
    termsTitle: "Шартлар брон пайтида белгиланади", termsBody: "Агар аниқ тариф, меҳмонхона ёки ҳамкор бошқа шартларни кўрсатса, улар устувор бўлади ва тўловдан олдин кўрсатилади. Тасдиқланган брон шартлари кейинчалик ёмонлаштирилмайди.",
    paymentTitle: "Қўлда тўлов хавфсизлиги", paymentSubtitle: "Реквизитлар, invoice ва тўлов тасдиғи аниқ брон билан боғланган.",
    paymentRules: [
      { icon: "numberCircle", title: "Реквизитлар фақат брон ичида", body: "Фақат аниқ броннинг ҳимояланган саҳифасида кўрсатилган реквизитлар бўйича тўланг. Ўтказмадан олдин брон рақами, сумма ва қабул қилувчини текширинг." },
      { icon: "creditCard", title: "Invoice ва чек", body: "Invoice брон маълумотларидан яратилади. Қўлда тўловдан кейин банк чеки сафарга бириктирилади ва тўловни текшириш учун ишлатилади." },
      { icon: "shield", title: "PIN ёки CVV сўралмайди", body: "iumrah PIN, CVV/CVC ёки банк иловаси паролини сўрамайди. Тўлов тасдиғи брон билан сақланади ва iumrah Care учун кўринади." },
    ],
  },
};

function RefundPolicySheet({ locale, done, onClose }: { locale: SiteLocale; done: string; onClose: () => void }) {
  const copy = CHECKOUT_POLICY_COPY[locale];
  return <BottomSheet title={copy.refundTitle} onClose={onClose}><div className={styles.policySheetBody}>
    <div className={styles.policyHero}><span className={styles.policyHeroIcon}><Symbol name="shield" size={20} /></span><div><strong>{copy.refundTitle}</strong><p>{copy.refundSubtitle}</p></div></div>
    <div className={styles.policyRules}>{copy.refundRules.map((rule) => <PolicyRule key={rule.title} rule={rule} />)}</div>
    <div className={styles.policyTerms}><strong>{copy.termsTitle}</strong><p>{copy.termsBody}</p></div>
  </div><button type="button" className={styles.sheetCta} onClick={onClose}>{done}</button></BottomSheet>;
}

function PaymentSecuritySheet({ locale, t, onClose }: { locale: SiteLocale; t: Copy; onClose: () => void }) {
  const copy = CHECKOUT_POLICY_COPY[locale];
  return <BottomSheet title={copy.paymentTitle} onClose={onClose}><div className={styles.policySheetBody}>
    <div className={`${styles.policyHero} ${styles.paymentPolicyHero}`}><span className={`${styles.policyHeroIcon} ${styles.paymentPolicyIcon}`}><Symbol name="creditCard" size={20} /></span><div><strong>{copy.paymentTitle}</strong><p>{copy.paymentSubtitle}</p></div></div>
    <div className={styles.paymentMiniNotice}><small>{t.paymentKicker}</small><strong>{t.paymentTitle}</strong><p>{t.paymentBody}</p></div>
    <div className={styles.policyRules}>{copy.paymentRules.map((rule) => <PolicyRule key={rule.title} rule={rule} />)}</div>
  </div><button type="button" className={styles.sheetCta} onClick={onClose}>{t.close}</button></BottomSheet>;
}

function PolicyRule({ rule }: { rule: CheckoutPolicyPoint }) {
  return <article className={styles.policyRule}><div className={styles.policyRuleHead}><span><Symbol name={rule.icon} size={16} /></span><div><strong>{rule.title}</strong>{rule.badge ? <small>{rule.badge}</small> : null}</div></div><p>{rule.body}</p></article>;
}

function ProfileCaptureSheet({ t, firstName, lastName, telegram, whatsapp, valid, submitting, setFirstName, setLastName, setTelegram, setWhatsapp, onClose, onSubmit }: {
  t: Copy; firstName: string; lastName: string; telegram: string; whatsapp: string; valid: boolean; submitting: boolean;
  setFirstName: (value: string) => void; setLastName: (value: string) => void; setTelegram: (value: string) => void; setWhatsapp: (value: string) => void; onClose: () => void; onSubmit: () => void;
}) {
  return <BottomSheet title={t.profileTitle} onClose={onClose}><div className={styles.sheetIntro}><span>{t.profileSection}</span><h2>{t.profileTitle}</h2><p>{t.profileBody}</p></div><div className={styles.form}><label><span>{t.firstName}</span><input value={firstName} onChange={(event) => setFirstName(event.target.value)} autoComplete="given-name" /></label><label><span>{t.lastName}</span><input value={lastName} onChange={(event) => setLastName(event.target.value)} autoComplete="family-name" /></label><label><span>{t.telegram}</span><input value={telegram} onChange={(event) => setTelegram(event.target.value)} autoCapitalize="none" placeholder="@username" /></label><label><span>{t.whatsapp}</span><input value={whatsapp} onChange={(event) => setWhatsapp(event.target.value)} autoComplete="tel" inputMode="tel" placeholder="+998 …" /></label></div><button type="button" className={styles.sheetCta} disabled={!valid || submitting} onClick={onSubmit}>{submitting ? <><span className={styles.spinner} />{t.ctaLoading}</> : <>{t.save}<Symbol name="chevronRight" size={16} /></>}</button></BottomSheet>;
}

function BottomSheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return <div className={styles.sheetBackdrop} role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) onClose(); }}><section className={styles.sheet} role="dialog" aria-modal="true" aria-label={title}><span className={styles.sheetHandle} /><div className={styles.sheetTop}><strong>{title}</strong><button type="button" onClick={onClose} aria-label="Close"><Symbol name="close" size={16} /></button></div>{children}</section></div>;
}
